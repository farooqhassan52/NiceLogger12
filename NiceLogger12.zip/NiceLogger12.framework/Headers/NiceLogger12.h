//
//  NiceLogger12.h
//  NiceLogger12
//
//  Created by Rana Farooq on 21/07/2020.
//  Copyright © 2020 AmcoItSystems. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for NiceLogger12.
FOUNDATION_EXPORT double NiceLogger12VersionNumber;

//! Project version string for NiceLogger12.
FOUNDATION_EXPORT const unsigned char NiceLogger12VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NiceLogger12/PublicHeader.h>


